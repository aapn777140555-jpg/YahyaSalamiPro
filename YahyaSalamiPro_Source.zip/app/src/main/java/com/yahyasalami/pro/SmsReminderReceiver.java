package com.yahyasalami.pro;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

public class SmsReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String phone=intent.getStringExtra("phone");
        String message=intent.getStringExtra("message");
        String debtId=intent.getStringExtra("debtId");
        if(phone==null || message==null) return;
        if(androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED) return;
        try {
            SmsManager.getDefault().sendTextMessage(phone,null,message,null,null);
            if(debtId!=null) context.getSharedPreferences("reminders",0).edit().putBoolean(debtId,true).apply();
        } catch(Exception ignored) {}
    }
}
